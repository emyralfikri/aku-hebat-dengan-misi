# Aku Anak Hebat - TK & KB
Aplikasi Birrul Walidain - Rekap Per Jenjang

Link akan jadi: https://username.github.io/aku-anak-hebat/

Cara pakai:
- Mode Guru password: Pena Ceria
- Tempel link Spreadsheet /exec di Mode Guru

Fitur: TK A (A1-A4), TK B (B1-B4), KB (KB1-KB2), Beranda editable, Rekap per jenjang
